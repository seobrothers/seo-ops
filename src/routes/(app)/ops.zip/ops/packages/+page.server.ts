import type { PageServerLoad } from './$types';
import { PackagesRepository } from '$lib/server/data/packages-repository';

export const load: PageServerLoad = async (event) => {
	const repo = new PackagesRepository(event);
	const includeInactive = event.url.searchParams.get('includeInactive') === 'true';
	const packages = await repo.getAll(includeInactive);

	return {
		packages,
		includeInactive,
		canEdit: event.locals.permissions.has('portal:service-item:edit') || event.locals.permissions.has('portal:campaign:edit')
	};
};