import type { PageServerLoad } from './$types';
import { ServiceCategoriesRepository } from '$lib/server/data/service-categories-repository';

export const load: PageServerLoad = async (event) => {
	const repo = new ServiceCategoriesRepository(event);
	const includeInactive = event.url.searchParams.get('includeInactive') === 'true';
	const serviceCategories = await repo.getAll(includeInactive);

	return {
		serviceCategories,
		includeInactive,
		canEdit: event.locals.permissions.has('portal:service-item:edit') || event.locals.permissions.has('portal:employee:edit'),
	};
};
